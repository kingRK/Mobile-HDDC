import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-opener',
  templateUrl: './opener.component.html',
  styleUrls: ['./opener.component.less']
})
export class OpenerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
