import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zip-results',
  templateUrl: './zip-results.component.html',
  styleUrls: ['./zip-results.component.less']
})
export class ZipResultsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
