export class Utilities {
  getHgt(elem) {
    
  }
}
