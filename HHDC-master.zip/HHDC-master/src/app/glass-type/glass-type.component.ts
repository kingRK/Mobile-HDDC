import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-glass-type',
  templateUrl: './glass-type.component.html',
  styleUrls: ['./glass-type.component.less']
})
export class GlassTypeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
