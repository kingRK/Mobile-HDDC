import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-repair',
  templateUrl: './service-repair.component.html',
  styleUrls: ['./service-repair.component.less']
})
export class ServiceRepairComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
