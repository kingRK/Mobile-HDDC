import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-construction',
  templateUrl: './construction.component.html',
  styleUrls: ['./construction.component.less']
})
export class ConstructionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
