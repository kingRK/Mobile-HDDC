import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-opener-selected',
  templateUrl: './opener-selected.component.html',
  styleUrls: ['./opener-selected.component.less']
})
export class OpenerSelectedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
